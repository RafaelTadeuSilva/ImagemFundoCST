@echo off
chcp 65001 >nul
title Desinstalador - Papel de Parede CST

echo ========================================================
echo   DESINSTALACAO DO ATUALIZADOR DE PAPEL DE PAREDE CST
echo ========================================================
echo.

echo Finalizando processos em execucao...
powershell -Command "Get-Process powershell -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like '*MonitorarWallpaper.ps1*' } | Stop-Process -Force -ErrorAction SilentlyContinue" >nul 2>&1

echo Removendo tarefas agendadas...
schtasks /Delete /TN "CST_AtualizarWallpaper" /F >nul 2>&1
schtasks /Delete /TN "CST_AtualizarWallpaper_Daily" /F >nul 2>&1
schtasks /Delete /TN "CST_Wallpaper_Guard" /F >nul 2>&1

echo Removendo inicializacao no logon (Todos os usuarios e Usuario atual)...
if exist "%ProgramData%\Microsoft\Windows\Start Menu\Programs\Startup\CST_Wallpaper_Guard.lnk" (
    del /F /Q "%ProgramData%\Microsoft\Windows\Start Menu\Programs\Startup\CST_Wallpaper_Guard.lnk" >nul 2>&1
)
if exist "%ProgramData%\Microsoft\Windows\Start Menu\Programs\Startup\CST_Wallpaper.lnk" (
    del /F /Q "%ProgramData%\Microsoft\Windows\Start Menu\Programs\Startup\CST_Wallpaper.lnk" >nul 2>&1
)
if exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\CST_Wallpaper_Guard.lnk" (
    del /F /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\CST_Wallpaper_Guard.lnk" >nul 2>&1
)
if exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\CST_Wallpaper.lnk" (
    del /F /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\CST_Wallpaper.lnk" >nul 2>&1
)

echo Removendo pastas de instalacao e cache...
if exist "%ProgramData%\CST_Wallpaper" (
    rmdir /S /Q "%ProgramData%\CST_Wallpaper" >nul 2>&1
)
if exist "%LOCALAPPDATA%\CST_Wallpaper" (
    rmdir /S /Q "%LOCALAPPDATA%\CST_Wallpaper" >nul 2>&1
)

echo.
echo ========================================================
echo [OK] Desinstalacao concluida com sucesso.
echo ========================================================
pause >nul
