<#
.SYNOPSIS
    Guardião de Papel de Parede CST (Modo Laboratório / Alunos)
.DESCRIPTION
    1. Mantém o papel de parede oficial do mês (GitHub CST) sempre ativo.
    2. Detecta imediatamente qualquer alteração feita por alunos/usuários e
       restaura o papel de parede oficial na hora.
    3. Atualiza automaticamente a imagem do mês quando houver virada de mês.
.AUTHOR
    CST
#>

[CmdletBinding()]
param(
    [int]$WaitSecondsBeforeRestore = 0,
    [int]$CheckIntervalSeconds = 5
)

# Ocultar janela de console imediatamente se estiver visível
$HideWindowCode = @"
using System;
using System.Runtime.InteropServices;
public class Win32Window {
    [DllImport("user32.dll")]
    public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
    [DllImport("kernel32.dll")]
    public static extern IntPtr GetConsoleWindow();
    public static void Hide() {
        IntPtr hWnd = GetConsoleWindow();
        if (hWnd != IntPtr.Zero) {
            ShowWindowAsync(hWnd, 0);
        }
    }
}
"@
if (-not ([System.Management.Automation.PSTypeName]'Win32Window').Type) {
    Add-Type -TypeDefinition $HideWindowCode -ErrorAction SilentlyContinue
}
try { [Win32Window]::Hide() } catch {}

# Suporte a TLS moderno
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12 -bor [System.Net.SecurityProtocolType]::Tls13 -bor [System.Net.SecurityProtocolType]::Tls

try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
} catch {}

$RepoBaseUrl = "https://raw.githubusercontent.com/RafaelTadeuSilva/ImagemFundoCST/main"
$FallbackImageName = "imagem_fundo.png"

$BaseDir = "$env:LOCALAPPDATA\CST_Wallpaper"
if (-not (Test-Path -Path $BaseDir)) {
    New-Item -ItemType Directory -Path $BaseDir -Force | Out-Null
}

$LogFile = Join-Path $BaseDir "guardiao.log"
$ActiveWallpaperPath = Join-Path $BaseDir "wallpaper_ativo.png"
$TranscodedPath = "$env:APPDATA\Microsoft\Windows\Themes\TranscodedWallpaper"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $logLine = "[$timestamp] [$Level] $Message"
    Add-Content -Path $LogFile -Value $logLine -Encoding UTF8 -ErrorAction SilentlyContinue
    if ($Host.Name -ne "Default Host") {
        Write-Host $logLine
    }
}

# Código C# nativo para User32.dll (definir papel de parede)
$SetWallpaperCode = @"
using System;
using System.Runtime.InteropServices;

public class CSTGuardWallpaper {
    public const int SPI_SETDESKWALLPAPER = 0x0014;
    public const int SPIF_UPDATEINIFILE = 0x01;
    public const int SPIF_SENDCHANGE = 0x02;

    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);

    public static bool Apply(string path) {
        int result = SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, path, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
        return result != 0;
    }
}
"@

if (-not ([System.Management.Automation.PSTypeName]'CSTGuardWallpaper').Type) {
    Add-Type -TypeDefinition $SetWallpaperCode -ErrorAction SilentlyContinue
}

function Download-MonthWallpaper {
    $currentMonth = (Get-Date).ToString("MM")
    $monthImageName = "imagem_fundo_${currentMonth}.png"
    $targetUrl = "$RepoBaseUrl/$monthImageName"
    $fallbackUrl = "$RepoBaseUrl/$FallbackImageName"
    $tempPath = Join-Path $BaseDir "temp_guard.png"
    $localMonthPath = Join-Path $BaseDir $monthImageName

    Write-Log "Verificando imagem oficial do mês $currentMonth no GitHub..."
    
    $downloaded = $false
    try {
        $wc = New-Object System.Net.WebClient
        $wc.Headers.Add("User-Agent", "Mozilla/5.0 CST-WallpaperGuard/1.0")
        $wc.DownloadFile($targetUrl, $tempPath)
        $wc.Dispose()
        $downloaded = $true
    } catch {
        try {
            $wc = New-Object System.Net.WebClient
            $wc.Headers.Add("User-Agent", "Mozilla/5.0 CST-WallpaperGuard/1.0")
            $wc.DownloadFile($fallbackUrl, $tempPath)
            $wc.Dispose()
            $downloaded = $true
        } catch {
            Write-Log "Não foi possível baixar nova imagem da web. Mantendo arquivos locais." "WARN"
        }
    }

    if ($downloaded -and (Test-Path -Path $tempPath)) {
        Move-Item -Path $tempPath -Destination $localMonthPath -Force
        Copy-Item -Path $localMonthPath -Destination $ActiveWallpaperPath -Force
    }
    elseif ((Test-Path -Path $localMonthPath) -and (-not (Test-Path -Path $ActiveWallpaperPath))) {
        Copy-Item -Path $localMonthPath -Destination $ActiveWallpaperPath -Force
    }
}

function Apply-OfficialWallpaper {
    if (-not (Test-Path -Path $ActiveWallpaperPath)) {
        Download-MonthWallpaper
    }

    if (Test-Path -Path $ActiveWallpaperPath) {
        try {
            Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name WallpaperStyle -Value "10" -Force -ErrorAction SilentlyContinue
            Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name TileWallpaper -Value "0" -Force -ErrorAction SilentlyContinue
            [CSTGuardWallpaper]::Apply($ActiveWallpaperPath) | Out-Null
            Write-Log "Papel de parede oficial aplicado com sucesso." "SUCCESS"
        }
        catch {
            Write-Log "Erro ao aplicar papel de parede: $($_.Exception.Message)" "ERROR"
        }
    }
}

function Get-WallpaperSignature {
    $regVal = ""
    try {
        $regVal = Get-ItemPropertyValue -Path 'HKCU:\Control Panel\Desktop' -Name Wallpaper -ErrorAction SilentlyContinue
    } catch {}

    $transHash = ""
    if (Test-Path -Path $TranscodedPath) {
        try {
            $transHash = (Get-FileHash -Path $TranscodedPath -Algorithm MD5 -ErrorAction SilentlyContinue).Hash
        } catch {}
    }

    return "$regVal|$transHash"
}

# Inicialização do Guardião
Write-Log "========================================================"
Write-Log "Iniciando Guardião de Papel de Parede CST (Restauração Imediata)"
Write-Log "Intervalo de checagem: $CheckIntervalSeconds segundos"
Write-Log "========================================================"

Download-MonthWallpaper
Apply-OfficialWallpaper
Start-Sleep -Seconds 2
$officialSignature = Get-WallpaperSignature

$lastMonthChecked = (Get-Date).Month
$lastHourlyCheck = Get-Date

# Loop contínuo de monitoramento
while ($true) {
    Start-Sleep -Seconds $CheckIntervalSeconds

    $now = Get-Date

    # Verificar virada de mês ou checagem periódica (a cada 6 horas)
    if ($now.Month -ne $lastMonthChecked -or ($now - $lastHourlyCheck).TotalHours -ge 6) {
        $lastMonthChecked = $now.Month
        $lastHourlyCheck = $now
        Download-MonthWallpaper
        Apply-OfficialWallpaper
        Start-Sleep -Seconds 2
        $officialSignature = Get-WallpaperSignature
        continue
    }

    $currentSignature = Get-WallpaperSignature

    # Detectar se o aluno/usuário alterou o papel de parede
    if ($currentSignature -ne $officialSignature) {
        Write-Log "Alteração de papel de parede detectada (Ação de usuário/aluno)." "WARN"
        
        if ($WaitSecondsBeforeRestore -gt 0) {
            Write-Log "Aguardando $WaitSecondsBeforeRestore segundos antes de restaurar..." "INFO"
            Start-Sleep -Seconds $WaitSecondsBeforeRestore
        }

        Write-Log "Restaurando papel de parede oficial imediatamente..." "INFO"
        Apply-OfficialWallpaper
        Start-Sleep -Seconds 2
        $officialSignature = Get-WallpaperSignature
    }
}
