<#
.SYNOPSIS
    Atualizador Automático de Imagem de Fundo (Wallpaper) - CST
.DESCRIPTION
    Identifica o mês atual, baixa a imagem correspondente do GitHub (imagem_fundo_01.png até 12.png)
    e aplica como papel de parede da área de trabalho no Windows de forma imediata e silenciosa.
.AUTHOR
    CST
#>

[CmdletBinding()]
param(
    [switch]$Force
)

# Garantir suporte aos protocolos TLS modernos (TLS 1.2 e 1.3)
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12 -bor [System.Net.SecurityProtocolType]::Tls13 -bor [System.Net.SecurityProtocolType]::Tls

# Configurações do Repositório
$RepoBaseUrl = "https://raw.githubusercontent.com/RafaelTadeuSilva/ImagemFundoCST/main"
$FallbackImageName = "imagem_fundo.png"

# Pastas de Armazenamento Local
$BaseDir = "$env:LOCALAPPDATA\CST_Wallpaper"
if (-not (Test-Path -Path $BaseDir)) {
    New-Item -ItemType Directory -Path $BaseDir -Force | Out-Null
}

$LogFile = Join-Path $BaseDir "historico.log"

try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
} catch {}

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $logLine = "[$timestamp] [$Level] $Message"
    Add-Content -Path $LogFile -Value $logLine -Encoding UTF8 -ErrorAction SilentlyContinue
    if ($Host.Name -ne "Default Host") {
        Write-Host $logLine
    }
}

Write-Log "--- Iniciando verificação de papel de parede ---"

# Identificar o mês atual (01 a 12)
$CurrentMonth = (Get-Date).ToString("MM")
$MonthImageName = "imagem_fundo_${CurrentMonth}.png"
$LocalImagePath = Join-Path $BaseDir $MonthImageName
$ActiveWallpaperPath = Join-Path $BaseDir "wallpaper_ativo.png"

$TargetUrl = "$RepoBaseUrl/$MonthImageName"
$FallbackUrl = "$RepoBaseUrl/$FallbackImageName"

Write-Log "Mês identificado: $CurrentMonth. Imagem esperada: $MonthImageName"

# Função para download com tratamento de erro
function Download-FileWithRetry {
    param(
        [string]$Url,
        [string]$Destination
    )
    try {
        $webClient = New-Object System.Net.WebClient
        $webClient.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) CST-WallpaperUpdater/1.0")
        $webClient.DownloadFile($Url, $Destination)
        $webClient.Dispose()
        return $true
    }
    catch {
        Write-Log "Falha ao baixar de $($Url): $($_.Exception.Message)" "WARN"
        return $false
    }
}

# Tentar baixar a imagem do mês atual
$downloadSuccess = $false
$tempDownloadPath = Join-Path $BaseDir "temp_download.png"

Write-Log "Tentando baixar: $TargetUrl"
$downloadSuccess = Download-FileWithRetry -Url $TargetUrl -Destination $tempDownloadPath

# Se não encontrar a imagem do mês (ex: 404), tenta imagem de fallback
if (-not $downloadSuccess) {
    Write-Log "Imagem do mês ($MonthImageName) não encontrada no repositório. Tentando fallback: $FallbackUrl" "WARN"
    $downloadSuccess = Download-FileWithRetry -Url $FallbackUrl -Destination $tempDownloadPath
}

# Processar arquivo baixado ou usar cache existente
$finalImagePath = $null

if ($downloadSuccess -and (Test-Path -Path $tempDownloadPath)) {
    # Salvar cópia nomeada do mês
    Move-Item -Path $tempDownloadPath -Destination $LocalImagePath -Force
    Copy-Item -Path $LocalImagePath -Destination $ActiveWallpaperPath -Force
    $finalImagePath = $ActiveWallpaperPath
    Write-Log "Imagem baixada e atualizada com sucesso em: $LocalImagePath"
}
elseif (Test-Path -Path $LocalImagePath) {
    Write-Log "Sem conexão com GitHub, mas imagem em cache local encontrada: $LocalImagePath" "INFO"
    Copy-Item -Path $LocalImagePath -Destination $ActiveWallpaperPath -Force
    $finalImagePath = $ActiveWallpaperPath
}
elseif (Test-Path -Path $ActiveWallpaperPath) {
    Write-Log "Usando último wallpaper ativo disponível em cache." "INFO"
    $finalImagePath = $ActiveWallpaperPath
}
else {
    Write-Log "Não foi possível obter imagem da internet nem do cache local." "ERROR"
    exit 1
}

# Configuração de Estilo no Registro do Windows (10 = Fill/Preencher, 0 = Sem Lado a Lado)
try {
    Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name WallpaperStyle -Value "10" -Force -ErrorAction SilentlyContinue
    Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name TileWallpaper -Value "0" -Force -ErrorAction SilentlyContinue
}
catch {
    Write-Log "Aviso ao gravar configurações no registro: $($_.Exception.Message)" "WARN"
}

# Código C# nativo para chamar SystemParametersInfo (User32.dll)
$SetWallpaperCode = @"
using System;
using System.Runtime.InteropServices;

public class CSTWallpaper {
    public const int SPI_SETDESKWALLPAPER = 0x0014;
    public const int SPIF_UPDATEINIFILE = 0x01;
    public const int SPIF_SENDCHANGE = 0x02;

    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);

    public static bool Apply(string path) {
        int result = SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, path, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
        return result != 0;
    }
}
"@

try {
    if (-not ([System.Management.Automation.PSTypeName]'CSTWallpaper').Type) {
        Add-Type -TypeDefinition $SetWallpaperCode -ErrorAction Stop
    }
    
    $applied = [CSTWallpaper]::Apply($finalImagePath)
    if ($applied) {
        Write-Log "Papel de parede aplicado com sucesso no Windows!" "SUCCESS"
    }
    else {
        Write-Log "Chamada à API SystemParametersInfo retornou código de falha." "WARN"
    }
}
catch {
    Write-Log "Erro ao aplicar papel de parede via API: $($_.Exception.Message)" "ERROR"
}

Write-Log "--- Verificação concluída ---`n"
