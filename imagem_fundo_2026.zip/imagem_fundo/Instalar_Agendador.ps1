<#
.SYNOPSIS
    Instalador do Atualizador de Papel de Parede CST
.DESCRIPTION
    Instala os arquivos no sistema e configura a inicialização automática via
    Agendador de Tarefas do Windows e Pasta de Inicialização do Usuário.
#>

try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
} catch {}

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "      INSTALADOR DO PAPEL DE PAREDE CST" -ForegroundColor Cyan
Write-Host "========================================================`n" -ForegroundColor Cyan

# Definir diretório de instalação
$IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if ($IsAdmin) {
    $TargetDir = "$env:ProgramData\CST_Wallpaper"
} else {
    $TargetDir = "$env:LOCALAPPDATA\CST_Wallpaper\app"
}

if (-not (Test-Path -Path $TargetDir)) {
    New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null
}

$CurrentDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "1. Copiando arquivos para: $TargetDir" -ForegroundColor White
Copy-Item -Path (Join-Path $CurrentDir "AtualizarWallpaper.ps1") -Destination $TargetDir -Force
Copy-Item -Path (Join-Path $CurrentDir "ExecutarOculto.vbs") -Destination $TargetDir -Force

$VbsPath = Join-Path $TargetDir "ExecutarOculto.vbs"

# 2. Configurar atalho na pasta Inicializar (Garante execução no Logon para qualquer usuário)
Write-Host "2. Configurando inicializacao automatica no Logon..." -ForegroundColor White
$StartupFolder = [Environment]::GetFolderPath("Startup")
$ShortcutPath = Join-Path $StartupFolder "CST_Wallpaper.lnk"

try {
    $WshShell = New-Object -ComObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut($ShortcutPath)
    $Shortcut.TargetPath = "wscript.exe"
    $Shortcut.Arguments = "`"$VbsPath`""
    $Shortcut.Description = "Atualizador de Papel de Parede CST"
    $Shortcut.WindowStyle = 7 # Minimized
    $Shortcut.Save()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($WshShell) | Out-Null
    Write-Host "   [OK] Inicializacao no logon configurada!" -ForegroundColor Green
}
catch {
    Write-Host "   [AVISO] Nao foi possivel criar atalho na pasta Startup: $($_.Exception.Message)" -ForegroundColor Yellow
}

# 3. Configurar Tarefa Agendada Diaria (Para atualizar no primeiro dia do mes sem precisar reiniciar)
Write-Host "3. Configurando verificacao diaria no Agendador de Tarefas..." -ForegroundColor White
$TaskName = "CST_AtualizarWallpaper"

try {
    $schtasksOutput = & schtasks.exe /Create /TN $TaskName /TR "wscript.exe `"$VbsPath`"" /SC DAILY /ST 08:00 /F 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "   [OK] Agendador de Tarefas configurado para 08:00 diariamente!" -ForegroundColor Green
    } else {
        Write-Host "   [INFO] Agendamento via Schtasks nao concluido: $schtasksOutput" -ForegroundColor Gray
    }
}
catch {
    Write-Host "   [INFO] Agendamento diario restrito, inicializacao no logon permanecera ativa." -ForegroundColor Gray
}

# 4. Executar primeira atualização imediatamente
Write-Host "`n4. Aplicando o papel de parede do mes atual agora..." -ForegroundColor Cyan
Start-Process -FilePath "wscript.exe" -ArgumentList "`"$VbsPath`"" -Wait

Write-Host "`n========================================================" -ForegroundColor Green
Write-Host "[SUCESSO] Instalacao finalizada com exito!" -ForegroundColor Green
Write-Host "O computador agora atualizara a imagem de fundo todo mes." -ForegroundColor Green
Write-Host "========================================================`n" -ForegroundColor Green
