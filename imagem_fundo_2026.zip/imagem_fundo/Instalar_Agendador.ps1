<#
.SYNOPSIS
    Instalador do Atualizador de Papel de Parede CST (Modo Padrão)
.DESCRIPTION
    Instala os arquivos no sistema e configura a inicialização automática no Logon
    e verificação diária. Configura para TODOS OS USUÁRIOS quando executado como Administrador.
#>

try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
} catch {}

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "      INSTALADOR DO PAPEL DE PAREDE CST (PADRÃO)" -ForegroundColor Cyan
Write-Host "========================================================`n" -ForegroundColor Cyan

$IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if ($IsAdmin) {
    Write-Host "[MODO ADMINISTRADOR DETECTADO]" -ForegroundColor Cyan
    Write-Host "Instalando para TODOS OS USUÁRIOS da máquina...`n" -ForegroundColor Gray
    $TargetDir = "$env:ProgramData\CST_Wallpaper"
    $StartupFolder = [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonStartup)
} else {
    Write-Host "[MODO USUÁRIO LOCAL DETECTADO]" -ForegroundColor Cyan
    Write-Host "Instalando para o usuário atual ($env:USERNAME)...`n" -ForegroundColor Gray
    $TargetDir = "$env:LOCALAPPDATA\CST_Wallpaper\app"
    $StartupFolder = [Environment]::GetFolderPath([Environment+SpecialFolder]::Startup)
}

if (-not (Test-Path -Path $TargetDir)) {
    New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null
}

$CurrentDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "1. Copiando arquivos para: $TargetDir" -ForegroundColor White
Copy-Item -Path (Join-Path $CurrentDir "AtualizarWallpaper.ps1") -Destination $TargetDir -Force

$ScriptPath = Join-Path $TargetDir "AtualizarWallpaper.ps1"
$PowerShellExe = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"

# 2. Configurar inicialização automática no Logon
Write-Host "2. Configurando inicializacao automatica no Logon..." -ForegroundColor White
$ShortcutPath = Join-Path $StartupFolder "CST_Wallpaper.lnk"

try {
    $WshShell = New-Object -ComObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut($ShortcutPath)
    $Shortcut.TargetPath = $PowerShellExe
    $Shortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ScriptPath`""
    $Shortcut.Description = "Atualizador de Papel de Parede CST"
    $Shortcut.WindowStyle = 7 # Minimized
    $Shortcut.Save()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($WshShell) | Out-Null
    Write-Host "   [OK] Inicializacao no logon configurada em: $StartupFolder" -ForegroundColor Green
}
catch {
    Write-Host "   [AVISO] Nao foi possivel criar atalho na pasta Startup: $($_.Exception.Message)" -ForegroundColor Yellow
}

# 3. Configurar Tarefa Agendada Diaria (Se Administrador)
if ($IsAdmin) {
    Write-Host "3. Configurando verificacao diaria no Agendador de Tarefas..." -ForegroundColor White
    $TaskName = "CST_AtualizarWallpaper"
    try {
        $taskTr = "`"$PowerShellExe`" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ScriptPath`""
        & schtasks.exe /Create /TN $TaskName /TR $taskTr /SC DAILY /ST 08:00 /F 2>&1 | Out-Null
        Write-Host "   [OK] Agendador de Tarefas configurado para 08:00 diariamente!" -ForegroundColor Green
    }
    catch {
        Write-Host "   [INFO] Agendamento diario restrito, inicializacao no logon permanecera ativa." -ForegroundColor Gray
    }
}

# 4. Executar primeira atualização
Write-Host "`n4. Aplicando o papel de parede agora..." -ForegroundColor Cyan
Start-Process -FilePath $PowerShellExe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ScriptPath`"" -Wait

Write-Host "`n========================================================" -ForegroundColor Green
Write-Host "[SUCESSO] Instalacao finalizada com exito!" -ForegroundColor Green
if ($IsAdmin) {
    Write-Host "Configurado para todos os usuários da máquina." -ForegroundColor Green
    Write-Host "Ao fazer login em qualquer perfil, o papel de parede será atualizado." -ForegroundColor Green
} else {
    Write-Host "Configurado para o usuário atual ($env:USERNAME)." -ForegroundColor Green
}
Write-Host "========================================================`n" -ForegroundColor Green
