<#
.SYNOPSIS
    Instalador do Modo Guardião de Papel de Parede CST (Laboratório / Alunos)
.DESCRIPTION
    Instala o monitor em segundo plano que restaura a imagem oficial imediatamente
    após qualquer alteração feita por alunos/usuários.
#>

try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
} catch {}

Write-Host "========================================================" -ForegroundColor Yellow
Write-Host "   INSTALADOR DO MODO GUARDIÃO (RESTAURAÇÃO IMEDIATA)" -ForegroundColor Yellow
Write-Host "========================================================`n" -ForegroundColor Yellow

# Definir diretório de instalação
$IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if ($IsAdmin) {
    $TargetDir = "$env:ProgramData\CST_Wallpaper"
} else {
    $TargetDir = "$env:LOCALAPPDATA\CST_Wallpaper\app"
}

if (-not (Test-Path -Path $TargetDir)) {
    New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null
}

$CurrentDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "1. Copiando arquivos do Guardiao para: $TargetDir" -ForegroundColor White
Copy-Item -Path (Join-Path $CurrentDir "MonitorarWallpaper.ps1") -Destination $TargetDir -Force
Copy-Item -Path (Join-Path $CurrentDir "ExecutarOculto_Guardiao.vbs") -Destination $TargetDir -Force
Copy-Item -Path (Join-Path $CurrentDir "AtualizarWallpaper.ps1") -Destination $TargetDir -Force
Copy-Item -Path (Join-Path $CurrentDir "ExecutarOculto.vbs") -Destination $TargetDir -Force

$VbsPath = Join-Path $TargetDir "ExecutarOculto_Guardiao.vbs"

# 2. Configurar inicialização no Logon (Pasta Startup)
Write-Host "2. Configurando inicializacao automatica no Logon do usuario..." -ForegroundColor White
$StartupFolder = [Environment]::GetFolderPath("Startup")
$ShortcutPath = Join-Path $StartupFolder "CST_Wallpaper_Guard.lnk"

try {
    $WshShell = New-Object -ComObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut($ShortcutPath)
    $Shortcut.TargetPath = "wscript.exe"
    $Shortcut.Arguments = "`"$VbsPath`""
    $Shortcut.Description = "Guardiao de Papel de Parede CST"
    $Shortcut.WindowStyle = 7
    $Shortcut.Save()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($WshShell) | Out-Null
    Write-Host "   [OK] Inicializacao no logon configurada!" -ForegroundColor Green
}
catch {
    Write-Host "   [AVISO] Nao foi possivel criar atalho na pasta Startup: $($_.Exception.Message)" -ForegroundColor Yellow
}

# 3. Configurar Tarefa Agendada no Logon
Write-Host "3. Registrando no Agendador de Tarefas do Windows..." -ForegroundColor White
$TaskName = "CST_Wallpaper_Guard"

try {
    $schtasksOutput = & schtasks.exe /Create /TN $TaskName /TR "wscript.exe `"$VbsPath`"" /SC ONLOGON /F 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "   [OK] Tarefa agendada configurada para iniciar no Logon!" -ForegroundColor Green
    } else {
        Write-Host "   [INFO] Schtasks ignorado (atalho no Logon ativo)." -ForegroundColor Gray
    }
}
catch {
    Write-Host "   [INFO] Agendamento via schtasks restrito, inicializacao no logon permanecera ativa." -ForegroundColor Gray
}

# 4. Iniciar o Guardião em segundo plano agora mesmo
Write-Host "`n4. Iniciando o Guardiao em segundo plano agora..." -ForegroundColor Cyan

# Finalizar processos anteriores se existirem
Get-Process powershell -ErrorAction SilentlyContinue | Where-Object {
    $_.CommandLine -like "*MonitorarWallpaper.ps1*"
} | Stop-Process -Force -ErrorAction SilentlyContinue

Start-Process -FilePath "wscript.exe" -ArgumentList "`"$VbsPath`""

Write-Host "`n========================================================" -ForegroundColor Green
Write-Host "[SUCESSO] MODO GUARDIÃO ATIVADO COM SUCESSO!" -ForegroundColor Green
Write-Host "Se algum aluno alterar o papel de parede, ele sera" -ForegroundColor Green
Write-Host "restaurado automaticamente para o padrao imediatamente." -ForegroundColor Green
Write-Host "========================================================`n" -ForegroundColor Green

