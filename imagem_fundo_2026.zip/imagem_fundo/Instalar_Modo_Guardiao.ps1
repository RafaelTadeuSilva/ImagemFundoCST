<#
.SYNOPSIS
    Instalador do Modo Guardião de Papel de Parede CST (Laboratório / Alunos)
.DESCRIPTION
    Instala o monitor em segundo plano que restaura a imagem oficial imediatamente
    após qualquer alteração feita por alunos/usuários.
    Configura para TODOS OS USUÁRIOS da máquina quando executado como Administrador.
#>

try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
} catch {}

Write-Host "========================================================" -ForegroundColor Yellow
Write-Host "   INSTALADOR DO MODO GUARDIÃO (RESTAURAÇÃO IMEDIATA)" -ForegroundColor Yellow
Write-Host "========================================================`n" -ForegroundColor Yellow

$IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if ($IsAdmin) {
    Write-Host "[MODO ADMINISTRADOR DETECTADO]" -ForegroundColor Cyan
    Write-Host "Instalando no sistema para valer em TODOS OS PERFIS DE USUÁRIOS (incluindo Aluno)...`n" -ForegroundColor Gray
    $TargetDir = "$env:ProgramData\CST_Wallpaper"
    $StartupFolder = [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonStartup)
} else {
    Write-Host "[MODO USUÁRIO LOCAL DETECTADO]" -ForegroundColor Cyan
    Write-Host "Instalando especificamente para o usuário atual ($env:USERNAME)...`n" -ForegroundColor Gray
    $TargetDir = "$env:LOCALAPPDATA\CST_Wallpaper\app"
    $StartupFolder = [Environment]::GetFolderPath([Environment+SpecialFolder]::Startup)
}

if (-not (Test-Path -Path $TargetDir)) {
    New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null
}

$CurrentDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "1. Copiando arquivos do Guardiao para: $TargetDir" -ForegroundColor White
Copy-Item -Path (Join-Path $CurrentDir "MonitorarWallpaper.ps1") -Destination $TargetDir -Force
Copy-Item -Path (Join-Path $CurrentDir "AtualizarWallpaper.ps1") -Destination $TargetDir -Force

$ScriptPath = Join-Path $TargetDir "MonitorarWallpaper.ps1"
$PowerShellExe = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"

# 2. Configurar inicialização automática no Logon
Write-Host "2. Configurando inicializacao automatica no Logon..." -ForegroundColor White
$ShortcutPath = Join-Path $StartupFolder "CST_Wallpaper_Guard.lnk"

try {
    $WshShell = New-Object -ComObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut($ShortcutPath)
    $Shortcut.TargetPath = $PowerShellExe
    $Shortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ScriptPath`""
    $Shortcut.Description = "Guardiao de Papel de Parede CST"
    $Shortcut.WindowStyle = 7 # Minimized
    $Shortcut.Save()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($WshShell) | Out-Null
    Write-Host "   [OK] Inicializacao no logon configurada em: $StartupFolder" -ForegroundColor Green
}
catch {
    Write-Host "   [AVISO] Nao foi possivel criar atalho na pasta Startup: $($_.Exception.Message)" -ForegroundColor Yellow
}

# 3. Configurar Tarefa Agendada no Logon (Se Administrador)
if ($IsAdmin) {
    Write-Host "3. Registrando no Agendador de Tarefas do Windows..." -ForegroundColor White
    $TaskName = "CST_Wallpaper_Guard"
    try {
        $taskTr = "`"$PowerShellExe`" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ScriptPath`""
        & schtasks.exe /Create /TN $TaskName /TR $taskTr /SC ONLOGON /F 2>&1 | Out-Null
        Write-Host "   [OK] Tarefa agendada configurada para o Logon de qualquer usuário!" -ForegroundColor Green
    }
    catch {
        Write-Host "   [INFO] Agendamento via schtasks ignorado (atalho no Logon já ativo)." -ForegroundColor Gray
    }
}

# 4. Iniciar processo
Write-Host "`n4. Ativando o Guardião..." -ForegroundColor Cyan

# Finalizar processos anteriores se existirem
Get-Process powershell -ErrorAction SilentlyContinue | Where-Object {
    $_.CommandLine -like "*MonitorarWallpaper.ps1*"
} | Stop-Process -Force -ErrorAction SilentlyContinue

Start-Process -FilePath $PowerShellExe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ScriptPath`""

Write-Host "`n========================================================" -ForegroundColor Green
Write-Host "[SUCESSO] MODO GUARDIÃO INSTALADO COM EXITO!" -ForegroundColor Green
if ($IsAdmin) {
    Write-Host "A proteção foi configurada para TODOS OS USUÁRIOS do computador." -ForegroundColor Green
    Write-Host "Sempre que o Aluno (ou qualquer outro usuário) fizer login," -ForegroundColor Green
    Write-Host "o papel de parede oficial será mantido e restaurado na hora." -ForegroundColor Green
    Write-Host "`nIMPORTANTE: Se o Aluno já estiver logado agora na máquina," -ForegroundColor Yellow
    Write-Host "basta fazer Logoff (Sair) e Logon (Entrar) na conta dele" -ForegroundColor Yellow
    Write-Host "ou dar 2 cliques em 'Executar_Agora.bat' na tela do Aluno!" -ForegroundColor Yellow
} else {
    Write-Host "O Guardião já está ativo para o usuário atual ($env:USERNAME)." -ForegroundColor Green
    Write-Host "Se o papel de parede for alterado, será restaurado imediatamente." -ForegroundColor Green
}
Write-Host "========================================================`n" -ForegroundColor Green
