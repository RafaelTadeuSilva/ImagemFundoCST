# Atualizador e Guardião de Papel de Parede - CST

Sistema completo para gerenciamento e padronização do papel de parede da área de trabalho no Windows, integrado ao repositório GitHub:
👉 **[RafaelTadeuSilva/ImagemFundoCST](https://github.com/RafaelTadeuSilva/ImagemFundoCST)**

---

## 🎯 Escolha o Modo de Instalação

Você pode escolher entre 2 modos conforme o tipo de computador:

### 1. 🛡️ Modo Guardião (Recomendado para Laboratórios e Alunos)
> **Ideal para:** Máquinas onde os alunos costumam mudar a imagem de fundo.
- Monitora em segundo plano a cada 5 segundos (0% de CPU).
- **Assim que o aluno troca o papel de parede, o Guardião detecta e restaura o oficial imediatamente.**
- Atualiza a imagem automaticamente na virada de cada mês.
- **Como instalar:** Dê dois cliques em **`Instalar_Modo_Guardiao.bat`**.

---

### 2. 📅 Modo Padrão (Recomendado para Máquinas Administrativas / Escritório)
> **Ideal para:** Computadores corporativos ou de uso geral.
- Verifica e aplica o papel de parede do mês no Logon e diariamente às 08:00.
- Não fica monitorando alterações contínuas.
- **Como instalar:** Dê dois cliques em **`Instalar_Agendador.bat`**.

---

## 📁 Estrutura dos Arquivos

| Arquivo | Descrição |
| :--- | :--- |
| **`Instalar_Modo_Guardiao.bat`** | **Instala o Modo Guardião** (restaura o papel de parede imediatamente se for alterado). |
| **`Instalar_Agendador.bat`** | **Instala o Modo Padrão** (troca no início do mês e ao logar). |
| **`Executar_Agora.bat`** | Atualiza a imagem imediatamente na tela para testes. |
| **`Desinstalar.bat`** | Remove o agendamento, desativa o guardião e limpa os arquivos. |
| `MonitorarWallpaper.ps1` | Script do Guardião com loop contínuo de detecção e restauração imediata. |
| `AtualizarWallpaper.ps1` | Script principal de download e aplicação do mês (`imagem_fundo_01.png` a `12.png`). |
| `ExecutarOculto.vbs` | Launcher silencioso (sem piscar janela preta). |
| `ExecutarOculto_Guardiao.vbs` | Launcher silencioso do Guardião. |

---

## ⚙️ Como Funciona o Guardião Imediato

```mermaid
graph LR
    A[Aluno altera o papel de parede] --> B[Guardião detecta alteração em 5s]
    B --> C[Restaura imagem oficial CST do mês imediatamente]
```

1. O script fica em segundo plano consumindo 0% de CPU.
2. Compara a assinatura do papel de parede ativo a cada 5 segundos.
3. Se detectada alteração pelo aluno, reaplica a imagem oficial do mês baixada do GitHub na mesma hora.
4. Caso o repositório ainda não tenha a imagem do mês correspondente, utiliza `imagem_fundo.png` de *fallback*.

---

## 🔍 Logs e Auditoria
- Log do Guardião: `%LOCALAPPDATA%\CST_Wallpaper\guardiao.log`
- Log do Atualizador: `%LOCALAPPDATA%\CST_Wallpaper\historico.log`
