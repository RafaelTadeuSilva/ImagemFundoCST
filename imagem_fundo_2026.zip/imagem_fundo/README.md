# Atualizador e Guardião de Papel de Parede - CST

Sistema para gerenciamento e padronização automática do papel de parede da área de trabalho no Windows, integrado ao repositório GitHub:
👉 **[RafaelTadeuSilva/ImagemFundoCST](https://github.com/RafaelTadeuSilva/ImagemFundoCST)**

---

## 🎯 Escolha o Modo de Instalação

### 1. 🛡️ Modo Guardião (Recomendado para Laboratórios / Máquinas de Alunos)
> **Ideal para:** Máquinas onde os alunos costumam trocar o papel de parede.
- Monitora em segundo plano a cada 5 segundos (0% de uso de CPU).
- **Assim que o aluno troca a imagem, ela é restaurada para a oficial imediatamente.**
- Atualiza a imagem automaticamente todo mês (`imagem_fundo_01.png` a `12.png`).
- **Instalação:** Dê dois cliques em **`Instalar_Modo_Guardiao.bat`**.

---

### 2. 📅 Modo Padrão (Recomendado para Máquinas de Escritório / Administrativas)
> **Ideal para:** Computadores gerais da instituição.
- Aplica a imagem do mês no Logon e diariamente às 08:00.
- Não monitora alterações contínuas.
- **Instalação:** Dê dois cliques em **`Instalar_Agendador.bat`**.

---

## 👥 Instalação em Máquinas de Alunos (Como Administrador vs Usuário)

Quando você for instalar em uma máquina com perfil de **Aluno**:

### Opção A: Executar como Administrador (Recomendado para Laboratórios)
1. Clique com o botão direito em `Instalar_Modo_Guardiao.bat` e escolha **"Executar como Administrador"**.
2. O instalador configurará o sistema em nível global (`C:\ProgramData` e `CommonStartup`).
3. A proteção passará a valer para **TODOS OS USUÁRIOS** da máquina (incluindo o perfil `Aluno`), e os alunos não terão permissão para apagar os scripts.
4. **Para ativar na tela do Aluno imediatamente:**
   - Faça **Logoff (Sair)** e **Logon (Entrar)** na conta do Aluno, **OU**
   - Dê 2 cliques em `Executar_Agora.bat` dentro da conta do Aluno.

### Opção B: Executar sem Administrador (Duplo clique normal)
1. Estando logado diretamente na conta do **Aluno**, dê apenas um **duplo clique comum** em `Instalar_Modo_Guardiao.bat`.
2. O papel de parede e o guardião serão ativados **na mesma hora** diretamente no perfil do Aluno, sem precisar de senha de administrador.

---

## 📁 Arquivos do Projeto

| Arquivo | Descrição |
| :--- | :--- |
| **`Instalar_Modo_Guardiao.bat`** | Instala o Modo Guardião (restauração imediata ao trocar). |
| **`Instalar_Agendador.bat`** | Instala o Modo Padrão (atualização no logon / diária). |
| **`Executar_Agora.bat`** | Força a atualização do papel de parede imediatamente na tela. |
| **`Desinstalar.bat`** | Remove o guardião, agendamentos e limpa os arquivos. |
| `MonitorarWallpaper.ps1` | Script do Guardião com auto-ocultação e loop de monitoramento. |
| `AtualizarWallpaper.ps1` | Script de download mensal e aplicação nativa via Windows API. |

---

## ☁️ Dica para Envio pelo Google Drive

Para compartilhar pelo Google Drive sem falsos positivos de antivírus:
1. Comprima a pasta em um arquivo **`.zip`**.
2. Os scripts antigos em formato `.vbs` (que disparavam o alerta do Google Drive) foram **totalmente removidos**. Agora o projeto utiliza apenas PowerShell nativo e atalhos do Windows.
