' Script VBScript para executar o Guardiao de Wallpaper 100% invisivel
Set objFSO = CreateObject("Scripting.FileSystemObject")
Set objShell = CreateObject("WScript.Shell")

strScriptDir = objFSO.GetParentFolderName(WScript.ScriptFullName)
strPS1Path = objFSO.BuildPath(strScriptDir, "MonitorarWallpaper.ps1")

strCommand = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & strPS1Path & """"
objShell.Run strCommand, 0, False

