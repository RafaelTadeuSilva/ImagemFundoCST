' Script VBScript para executar o PowerShell de forma 100% invisivel (sem flash de janela)
Set objFSO = CreateObject("Scripting.FileSystemObject")
Set objShell = CreateObject("WScript.Shell")

strScriptDir = objFSO.GetParentFolderName(WScript.ScriptFullName)
strPS1Path = objFSO.BuildPath(strScriptDir, "AtualizarWallpaper.ps1")

strCommand = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & strPS1Path & """"
objShell.Run strCommand, 0, False

