@echo off
chcp 65001 >nul
title Instalador - Atualizador de Papel de Parede CST

echo ========================================================
echo   INSTALACAO DO ATUALIZADOR DE PAPEL DE PAREDE CST
echo ========================================================
echo.
echo Instalando arquivos e configurando agendamento automatico...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar_Agendador.ps1"

echo.
echo ========================================================
echo Pressione qualquer tecla para finalizar.
echo ========================================================
pause >nul

