@echo off
chcp 65001 >nul
title Instalador Modo Guardião - Papel de Parede CST

echo ========================================================
echo   INSTALACAO DO MODO GUARDIAO - PAPEL DE PAREDE CST
echo   (Restaura o papel de parede imediatamente se alterado)
echo.
echo Instalando arquivos e iniciando monitoramento...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar_Modo_Guardiao.ps1"

echo.
echo ========================================================
echo Pressione qualquer tecla para finalizar.
echo ========================================================
pause >nul

