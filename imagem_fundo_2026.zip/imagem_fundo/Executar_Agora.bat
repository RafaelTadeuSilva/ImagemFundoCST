@echo off
chcp 65001 >nul
title Atualizador de Papel de Parede CST

echo ========================================================
echo     ATUALIZADOR DE PAPEL DE PAREDE MENSAL - CST
echo ========================================================
echo.
echo Executando verificacao e atualizacao do wallpaper...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0AtualizarWallpaper.ps1"

echo.
echo ========================================================
echo Processo finalizado! Pressione qualquer tecla para sair.
echo ========================================================
pause >nul

